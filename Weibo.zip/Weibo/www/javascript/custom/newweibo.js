$(function(){
	$(".send-btn").click(function(){
		var uid=getToken();
		var content=$("#content").val();
		$.post(host+"statuses/update",{content:content,token:uid},function(data){
			if(data.update){
				location.href="./home.html?token="+uid;
			}
		})
	})
})
