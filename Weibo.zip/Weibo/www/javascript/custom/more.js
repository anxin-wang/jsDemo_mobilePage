// If you want to prevent dragging, uncomment this section

 function preventBehavior(e)
 {
 e.preventDefault();
 };
 document.addEventListener("touchmove", preventBehavior, false);
			 


$(function(){
	myScroll = new iScroll('scroller');
	var uid=getToken();
	setFooterNavToken(uid);
	$("#logout-btn").click(function(e){
		
		e.preventDefault();
		$.get(host+"account/end_session",{token:uid},function(data){
			if(data.status){
				$.cookie('mobile', null);
				$.cookie('password', null);
				$.cookie('username', null);
				location.href="./index.html";
			}
		})
	})
})
