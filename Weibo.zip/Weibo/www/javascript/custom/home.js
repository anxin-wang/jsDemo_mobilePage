// If you want to prevent dragging, uncomment this section
function preventBehavior(e)
{
 	e.preventDefault();
};
document.addEventListener("touchmove", preventBehavior, false);

/*******************jQuery*******************/
$(function(){
	myScroll = new iScroll('scroller');
	var uid=getToken();
	setFooterNavToken(uid);
	/*
	 * path:
			statuses/user_timeline
		parameters:
			uid: int, default: current_user.id //current_user为当前已登录用户的ID
			page: int, default:1
			count: int, default:20
			max_id:int //获取小于此ID后的微博列表，page和max_id只提供其中一个就可
		result:
			同statuses/mentions
		example:
			http://t.e-doctor.cn/api/statuses/user_timeline?uid=1&max_id=10
	 */

	
	$("h1").text($.cookie('username'));
	 $.get(host+"statuses/index",{token:uid,page:1},function(data){
	 	if(data.error){
	 		location.href="index.html";
	 	}else{
	 		$("#scroller").weibolist(data.list);
	 	}
	})
	$(".new-weibo-btn").attr("href","newweibo.html?token="+uid);
	$(".arrow-btn").attr("href","profile.html?token="+uid);
	$(".refresh-btn").attr("href","home.html?token="+uid);
	
	
})