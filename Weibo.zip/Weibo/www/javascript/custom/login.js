// If you want to prevent dragging, uncomment this section
			
function preventBehavior(e)
{
 	e.preventDefault();
};
document.addEventListener("touchmove", preventBehavior, false);
/***************jQuery********************/
$(function(){
	$("#name").val($.cookie('mobile'));
	$("#password").val($.cookie('password'));
	$("#login-btn").click(function(e){
		e.preventDefault();
		 var name=$("#name").val(),
			 password=$("#password").val();
			//var name="18601665964",password="665964";
		if((name =="") || (password =="")){
			//alert("用户名和密码不能为空！");
            navigator.notification.alert('用户名和密码不能为空！');

		}else{
            $.get(host+"account/verify_credentials",{mobile:name,password:password},function(data){
                  if((data.error)&&(data.error=="invalid mobile")){
                  	 navigator.notification.alert('用户名和密码不正确');
                  	 //alert("用户名和密码不正确");
                  }else if(data.token){
                  	$.cookie('mobile',name,{expires:14});
                  	$.cookie('password',password,{expires:14});
                  	$.cookie('username',data.username,{expires:14});
                  	location.href="./home.html?token="+data.token;
                  }
        });
		}
	})
	
})