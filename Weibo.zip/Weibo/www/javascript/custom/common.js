var host="http://i.e-doctor.cn/api/";
//var host = "http://localhost:3000/api/";
function getToken(){
	var uid=location.search.slice(7);
	return uid;
}
function setFooterNavToken(uid){
		$(".nav-home").attr("href","home.html?token="+uid);
		$(".nav-message").attr("href","message.html?token="+uid);
		$(".nav-profile").attr("href","profile.html?token="+uid);
		$(".nav-topic").attr("href","topic.html?token="+uid);
		$(".nav-more").attr("href","more.html?token="+uid);
}

