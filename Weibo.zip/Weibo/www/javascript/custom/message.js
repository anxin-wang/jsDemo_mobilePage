$(function(){
	myScroll = new iScroll('scroller');
	var uid=getToken();
	setFooterNavToken(uid);
	//if(){
		$.get(host+"statuses/mentions",{token:uid,page:1},function(data){
	 	if(data.error){
	 		location.href="index.html";
	 	}else{
	 		$("#scroller").weibolist(data.list);
	 	}
	})
	$('div').live('pagecreate',function(event, ui){
		
  		setFooterNavToken(uid);
	});
	//}
})
